-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2020 at 08:16 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbobat`
--

-- --------------------------------------------------------

--
-- Table structure for table `dbjual`
--

CREATE TABLE `dbjual` (
  `id` int(11) NOT NULL,
  `kode_obat` varchar(255) NOT NULL,
  `nama_obat` varchar(255) NOT NULL,
  `bentuk_obat` varchar(255) NOT NULL,
  `berat_obat` varchar(255) NOT NULL,
  `harga_obat` int(10) NOT NULL,
  `stok_obat` int(10) NOT NULL,
  `harga_total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dbstok`
--

CREATE TABLE `dbstok` (
  `id` int(10) NOT NULL,
  `kode_obat` varchar(255) NOT NULL,
  `nama_obat` varchar(255) NOT NULL,
  `bentuk_obat` varchar(255) NOT NULL,
  `berat_obat` varchar(255) NOT NULL,
  `harga_obat` int(10) NOT NULL,
  `stok_obat` int(10) NOT NULL,
  `harga_total` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbstok`
--

INSERT INTO `dbstok` (`id`, `kode_obat`, `nama_obat`, `bentuk_obat`, `berat_obat`, `harga_obat`, `stok_obat`, `harga_total`) VALUES
(1, 'KD-555', 'UltraFlu', 'Kapsul', '50 mg', 5000, 6, 30000),
(3, 'KD-515', 'Bodrex', 'Tablet', '10 mg', 500, 20, 10000),
(4, 'KD-505', 'Antangin', 'Kapsul', '5 mg', 2000, 10, 20000),
(6, 'KD-500', 'Diapet', 'Kapsul', '16 mg', 7500, 4, 0),
(7, 'KD-105', 'Sanaflu', 'Tablet', '5 mg', 5000, 5, 0),
(8, 'KD-100', '2', '2', '2', 2, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'eka', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dbjual`
--
ALTER TABLE `dbjual`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dbstok`
--
ALTER TABLE `dbstok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dbjual`
--
ALTER TABLE `dbjual`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `dbstok`
--
ALTER TABLE `dbstok`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
