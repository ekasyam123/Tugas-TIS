﻿Public Class Form_Keluar

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox4.Text <> "" And TextBox5.Text <> "" And TextBox6.Text <> "" And TextBox3.Text <> "") Then
            SimpanDataObat()
            ClearEntry()
        Else
            MessageBox.Show("Isi data dengan lengkap!")
        End If
    End Sub
    Private Sub Ambil()
        If (keluar_baru = False And TextBox1.Text <> "") Then
            oKeluar.Ambil(TextBox1.Text)
            TextBox1.Clear()
            Reload()
        End If
    End Sub
    Private Sub ClearEntry()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox7.Clear()
        TextBox6.Clear()
        TextBox1.Focus()
    End Sub
    Private Sub SimpanDataObat()

        oKeluar.kode_obat = TextBox1.Text
        oObat.nama_obat = TextBox2.Text
        oObat.bentuk_obat = TextBox3.Text
        oObat.berat_obat = TextBox4.Text
        oObat.harga_obat = TextBox5.Text
        oObat.stok_obat = TextBox6.Text

        Ambil()

    End Sub
    Private Sub Reload()
        oKeluar.getAllData(DataGridView1)

    End Sub

    Private Sub TampilObat()
        TextBox1.Text = oObat.kode_obat
        TextBox2.Text = oObat.nama_obat
        TextBox3.Text = oObat.bentuk_obat
        TextBox4.Text = oObat.berat_obat
        TextBox5.Text = oObat.harga_obat
    End Sub

    Private Sub TextBox7_MouseClick(sender As Object, e As MouseEventArgs) Handles TextBox7.MouseClick
        
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        oKeluar.Hapus()

        Form_Menu.Show()
        Me.Hide()

    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            oObat.CariObat(TextBox1.Text)
            If (obat_baru = False) Then
                TampilObat()
            Else
                MessageBox.Show("Data Obat Tidak Ditemukan")
                ClearEntry()

            End If
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ClearEntry()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Form_Keluar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim r As New Random
        TextBox8.Text = New String(TextBox8.Text.ToCharArray.OrderBy(Function(c) r.NextDouble).ToArray)

    End Sub

    Private Sub Form_Keluar_MouseClick(sender As Object, e As MouseEventArgs) Handles Me.MouseClick
        Reload()
        If TextBox5.Text = "" And TextBox6.Text = "" Then
        Else
            Dim bil1 As Integer = TextBox5.Text
            Dim bil2 As Integer = TextBox6.Text
            Dim hasil As Integer
            hasil = bil1 * bil2
            TextBox7.Text = hasil
        End If
    End Sub
End Class