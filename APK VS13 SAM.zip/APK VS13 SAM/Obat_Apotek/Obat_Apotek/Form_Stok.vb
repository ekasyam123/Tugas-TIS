﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms

Public Class Form_Stok
    Dim rpt As New classreport
    Dim ds As New DataSet1

    Private Sub Form_Stok_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rpt.HostName = "localhost"
        rpt.DatabaseName = "dbobat"
        rpt.DatabaseUsername = "root"
        rpt.DatabasePassword = ""

        rpt.DataSetName = "DataSet1"
        rpt.DataTableName = "dbpenjualan"
        rpt.ReportFilename = "Report1.rdlc"
        rpt.SqlQuery = "select * from dbstok"

        rpt.LoadReport(ReportViewer1, ds)
    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load

    End Sub
End Class