﻿Public Class Obat
    Dim strsql As String
    Dim info As String
    Private _id As Integer
    Private _kode_obat As String
    Private _nama_obat As String
    Private _bentuk_obat As String
    Private _berat_obat As String
    Private _harga_obat As String
    Private _stok_obat As String
    Private _aa As String
    Private _total_harga As String

    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property kode_obat()
        Get
            Return _kode_obat
        End Get
        Set(ByVal value)
            _kode_obat = value
        End Set
    End Property
    Public Property aa()
        Get
            Return _aa
        End Get
        Set(ByVal value)
            _aa = value
        End Set
    End Property
    Public Property id()
        Get
            Return _id
        End Get
        Set(ByVal value)
            _id = value
        End Set
    End Property
    Public Property nama_obat()
        Get
            Return _nama_obat
        End Get
        Set(ByVal value)
            _nama_obat = value
        End Set
    End Property
    Public Property bentuk_obat()
        Get
            Return _bentuk_obat
        End Get
        Set(ByVal value)
            _bentuk_obat = value
        End Set
    End Property
    Public Property berat_obat()
        Get
            Return _berat_obat
        End Get
        Set(ByVal value)
            _berat_obat = value
        End Set
    End Property
    Public Property harga_obat()
        Get
            Return _harga_obat
        End Get
        Set(ByVal value)
            _harga_obat = value
        End Set
    End Property
    Public Property total_harga()
        Get
            Return _total_harga
        End Get
        Set(ByVal value)
            _total_harga = value
        End Set
    End Property
    Public Property stok_obat()
        Get
            Return _stok_obat
        End Get
        Set(ByVal value)
            _stok_obat = value
        End Set
    End Property
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT kode_obat, nama_obat, bentuk_obat, berat_obat, harga_obat, stok_obat FROM dbstok"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (obat_baru = True) Then
            strsql = "Insert into dbstok(kode_obat,nama_obat,bentuk_obat,berat_obat,harga_obat,stok_obat) values ('" & _kode_obat & "','" & _nama_obat & "','" & _bentuk_obat & "','" & _berat_obat & "','" & _harga_obat & "','" & _stok_obat & "')"
            info = "INSERT"
        Else
            strsql = "update dbstok set kode_obat='" & _kode_obat & "', nama_obat='" & _nama_obat & "', bentuk_obat='" & _bentuk_obat & "', berat_obat='" & _berat_obat & "', harga_obat='" & _harga_obat & "', stok_obat='" & _stok_obat & "' where kode_obat='" & _kode_obat & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub CariObat(ByVal skode_obat As String)
        DBConnect()
        SQL = "SELECT * FROM dbstok WHERE kode_obat='" & skode_obat & "'"
        myCommand.Connection = conn
        myCommand.CommandText = SQL
        DR = myCommand.ExecuteReader

        If (DR.HasRows = True) Then
            obat_baru = False
            DR.Read()
            kode_obat = Convert.ToString((DR("kode_obat")))
            nama_obat = Convert.ToString((DR("nama_obat")))
            bentuk_obat = Convert.ToString((DR("bentuk_obat")))
            berat_obat = Convert.ToString((DR("berat_obat")))
            harga_obat = Convert.ToString((DR("harga_obat")))
            stok_obat = Convert.ToString((DR("stok_obat")))
        Else
            obat_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal skode_obat As String)
        Dim info As String
        DBConnect()
        SQL = "DELETE FROM dbstok WHERE kode_obat='" & skode_obat & "'"
        info = "Data berhasil dihapus"
        myCommand.Connection = conn
        myCommand.CommandText = SQL
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub

End Class
